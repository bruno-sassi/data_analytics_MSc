# utils.py
# Sleep-related helper functions

def quality_label(score):
    if score >= 85:
        return "Excellent"
    elif score >= 70:
        return "Good"
    elif score >= 50:
        return "Fair"
    else:
        return "Poor"

def normalize_quality(score, current_max=100):
    """Normalize a single numeric score to 0-100.
    Guards: if current_max is 0/None or inputs are not numeric, return 0.0.
    """
    if current_max in (0, None):
        return 0.0
    try:
        return round((float(score) / float(current_max)) * 100.0, 2)
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0

def compute_sleep_score(duration, quality_score):
    # 0-100 scale: cap duration contribution at 8h => 60 pts; quality contributes 40%.
    score = min(duration / 8.0, 1.0) * 60.0 + (quality_score * 0.4)
    return round(min(score, 100.0), 2)
