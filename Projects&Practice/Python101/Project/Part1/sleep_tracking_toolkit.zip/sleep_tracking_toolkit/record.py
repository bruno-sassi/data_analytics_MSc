# record.py
# Daily record model and helpers for one day's sleep
from .utils import compute_sleep_score, quality_label

class DailySleepRecord:
    def __init__(self, date, segments):
        # date: 'YYYY-MM-DD' string
        # segments: list of (duration_hours: float, quality_score: int/float 0-100)
        self.date = date
        self.segments = segments or []

    def average_quality(self):
        if not self.segments:
            return 0.0
        total_q = sum(q for _, q in self.segments)
        return round(total_q / len(self.segments), 2)

    def total_duration(self):
        if not self.segments:
            return 0.0
        total_h = sum(d for d, _ in self.segments)
        return round(total_h, 2)

    def is_restful(self, duration_threshold=7, quality_threshold=75):
        # Reasonable behavior: a day without segments is not restful.
        if not self.segments:
            return False
        return all(
            (d >= duration_threshold) and (q >= quality_threshold)
            for d, q in self.segments
        )

    def average_sleep_score(self):
        if not self.segments:
            return 0.0
        scores = [compute_sleep_score(d, q) for d, q in self.segments]
        return round(sum(scores) / len(scores), 2)

    def summary(self):
        avg_quality = self.average_quality()
        total_duration = self.total_duration()
        avg_sleep_score = self.average_sleep_score()
        label = quality_label(avg_sleep_score)
        return {
            "date": self.date,
            "avg_quality": avg_quality,
            "total_duration": total_duration,
            "avg_sleep_score": avg_sleep_score,
            "quality_label": label,
        }
