# analytics.py
# Analysis utilities across multiple records / series

from .utils import compute_sleep_score

def overall_average_duration(records):
    """Average duration across *all segments* of all records.
    Returns 0.0 when no records or no segments exist.
    """
    if not records:
        return 0.0
    total = 0.0
    count = 0
    for rec in records:
        segs = getattr(rec, "segments", []) or []
        for d, _ in segs:
            total += d
            count += 1
    if count == 0:
        return 0.0
    return round(total / count, 2)

def best_sleep_day(records):
    """Return the date of the record with the highest average sleep score.
    Returns None for empty input.
    """
    if not records:
        return None
    best = max(records, key=lambda r: r.average_sleep_score(), default=None)
    return None if best is None else best.date

def detect_under_sleep_days(records, threshold):
    """Return list of dates where *any* segment duration is below threshold.
    Each date appears at most once.
    """
    if not records:
        return []
    dates = []
    for rec in records:
        segs = getattr(rec, "segments", []) or []
        for d, _ in segs:
            if d < threshold:
                dates.append(rec.date)
                break
    return dates

def detect_spike(durations, *, threshold=2):
    """Return True if any two consecutive values differ by >= threshold (jump or drop)."""
    if not durations or len(durations) < 2:
        return False
    for i in range(1, len(durations)):
        if abs(durations[i] - durations[i - 1]) >= threshold:
            return True
    return False

def duration_trend(durations):
    """Return list of 'up'/'down'/'same' for consecutive changes. Empty list for <2 points."""
    if not durations or len(durations) < 2:
        return []
    trend = []
    for i in range(1, len(durations)):
        if durations[i] > durations[i - 1]:
            trend.append("up")
        elif durations[i] < durations[i - 1]:
            trend.append("down")
        else:
            trend.append("same")
    return trend

def average_sleep_score_across_days(records):
    """Average of all *segment-level* sleep scores across all records."""
    if not records:
        return 0.0
    scores = []
    for rec in records:
        segs = getattr(rec, "segments", []) or []
        for d, q in segs:
            scores.append(compute_sleep_score(d, q))
    if not scores:
        return 0.0
    return round(sum(scores) / len(scores), 2)
